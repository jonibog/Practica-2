const db = require ('../../db/mysql');

const tabla= 'clientes';

function todos (){
    return db.todos(tabla);
}

module.exports = {
todos,
}
