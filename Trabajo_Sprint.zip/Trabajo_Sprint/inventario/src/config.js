require('dotenv').config();

module.exports = {
  App:{
    port: process.env.PORT || 8000,
  },
  mysql : {
    host : process.env.MYSQL_HOST || 'localhost',
    usuario : process.env.MYSQL_USER || 'root',
    password : process.env.MYSQL_PASSWORD || '',
    database: process.env.MYSQL_DB || 'Ferreteria',
  }

}
